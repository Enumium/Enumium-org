# USLand prototype (static)

Three static pages, no build step and no server code:

- `index.html`: public site prototype (served at /usland/)
- `admin/index.html`: broker admin prototype (served at /usland/admin/)
- `portal/index.html`: buyer and owner deal portal (served at /usland/portal/)

Upload this `usland` folder to the web root of silocloud.dev so the URLs become
https://silocloud.dev/usland/ and https://silocloud.dev/usland/admin/.

Notes
- Everything (images, map data, logo, the PeerJS video library) is inlined. Google Fonts and the
  free PeerJS signaling server (0.peerjs.com) are the only outside services.
- Video calls: the Video call button on a listing rings the Video desk in the admin
  (/usland/admin/#desk) when someone there has "Take video calls" switched on. Video and audio go
  browser to browser (WebRTC); notes saved on the desk land in Customers, Calls and the pipeline.
- Both pages carry `noindex` so search engines skip the prototype.
- The admin page is open (no password) by request; it shows sample data only.
- Deal portal: buyers and owners sign up with an email, sign documents on screen (pdf-lib stamps the
  signature into the PDF; pdf.js shows the pages) and message the broker. The broker works the same
  deals under Deal rooms in the admin. For the demo, records live in the browser (localStorage +
  IndexedDB), shared by all three pages on the same site, so one browser shows all three sides.
- Listing sign-up: "List a property" opens a 7-step flow in the portal (/usland/portal/#list). The owner
  signs the listing agreement on screen; the broker approves it under Listings in the admin.
- Auctions (/usland/#auctions): timed online bidding with registration, proxy (maximum) bids, a private
  reserve and a 2-minute soft close. The broker ends and awards lots in the admin, which sends the
  winner a sale contract in the deal portal. The two seeded lots are labeled samples.
- Bulletin (/usland/#bulletin): news, wanted ads, coming soon and events. Public posts wait for the
  broker's approval in the admin.
