# USLand prototype (static)

Two static pages, no build step and no server code:

- `index.html`: public site prototype (served at /usland/)
- `admin/index.html`: broker admin prototype (served at /usland/admin/)

Upload this `usland` folder to the web root of silocloud.dev so the URLs become
https://silocloud.dev/usland/ and https://silocloud.dev/usland/admin/.

Notes
- Everything (images, map data, logo) is inlined. Only Google Fonts loads from outside.
- Both pages carry `noindex` so search engines skip the prototype.
- The admin page is open (no password) by request; it shows sample data only.
