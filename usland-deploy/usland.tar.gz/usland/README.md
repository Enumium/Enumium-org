# USLand prototype (static)

Two static pages, no build step and no server code:

- `index.html`: public site prototype (served at /usland/)
- `admin/index.html`: broker admin prototype (served at /usland/admin/)

Upload this `usland` folder to the web root of silocloud.dev so the URLs become
https://silocloud.dev/usland/ and https://silocloud.dev/usland/admin/.

Notes
- Everything (images, map data, logo, the PeerJS video library) is inlined. Google Fonts and the
  free PeerJS signaling server (0.peerjs.com) are the only outside services.
- Video calls: the Video call button on a listing rings the Video desk in the admin
  (/usland/admin/#desk) when someone there has "Take video calls" switched on. Video and audio go
  browser to browser (WebRTC); notes saved on the desk land in Customers, Calls and the pipeline.
- Both pages carry `noindex` so search engines skip the prototype.
- The admin page is open (no password) by request; it shows sample data only.
